import React, { useState } from 'react';
import { 
  Orbit, 
  LayoutDashboard, 
  CalendarClock, 
  Layers, 
  MessageSquare, 
  Bell, 
  Settings, 
  Search, 
  Plus, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  UserPlus, 
  Sparkles, 
  AlertOctagon, 
  Cloud, 
  Database, 
  Terminal, 
  Mail, 
  History, 
  Circle,
  MoreVertical,
  ChevronUp,
  ChevronDown,
  Send,
  Paperclip,
  TrendingUp,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

/**
 * Orbit AI: A high-fidelity dashboard for founders.
 */

// --- Shared Components ---

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  [key: string]: any;
}

const GlassCard = ({ children, className = "", ...props }: GlassCardProps) => (
  <div className={`glass-card rounded-xl p-6 ${className}`} {...props}>
    {children}
  </div>
);

const Sidebar = ({ currentTab, onTabChange }) => {
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'follow-ups', label: 'Follow-ups', icon: CalendarClock },
    { id: 'stack-monitor', label: 'Stack Monitor', icon: Layers },
    { id: 'chat', label: 'Chat', icon: MessageSquare },
  ];

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 border-r border-white/10 bg-[#0a0a0f]/80 backdrop-blur-md flex flex-col z-40">
      <div className="p-6 flex items-center gap-4">
        <div className="w-10 h-10 rounded-lg bg-primary-container flex items-center justify-center ai-glow">
          <Orbit className="text-white w-6 h-6" />
        </div>
        <div>
          <h1 className="text-xl font-black tracking-tighter text-white uppercase">Orbit AI</h1>
          <p className="text-[10px] uppercase tracking-widest text-[#7c3aed] font-bold">Founder Intel</p>
        </div>
      </div>

      <nav className="flex-1 mt-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`w-full flex items-center gap-3 px-6 py-3 transition-all cursor-pointer ${
              currentTab === tab.id 
                ? 'text-primary bg-primary-container/10 border-r-2 border-primary' 
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <tab.icon className={`w-5 h-5 ${currentTab === tab.id ? 'fill-primary/20' : ''}`} />
            <span className="font-medium">{tab.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6 border-t border-white/10">
        <div className="flex items-center gap-3 p-3 glass-card rounded-xl">
          <img 
            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=64&h=64" 
            alt="Alex Rivera"
            className="w-10 h-10 rounded-full border border-primary/20"
          />
          <div className="overflow-hidden">
            <p className="text-white font-bold truncate">Alex Rivera</p>
            <p className="text-xs text-slate-500 truncate">Pro Plan</p>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-4 ml-2">
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse shadow-[0_0_8px_#7c3aed]" />
          <span className="text-[10px] font-bold text-primary uppercase tracking-widest">AI Core Active</span>
        </div>
      </div>
    </aside>
  );
};

const TopBar = () => {
  return (
    <header className="fixed top-0 left-64 right-0 h-16 bg-[#0a0a0f]/60 backdrop-blur-lg border-b border-white/10 flex items-center justify-between px-6 z-30">
      <div className="flex-1 max-w-md">
        <div className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-primary transition-colors w-4 h-4" />
          <input 
            type="text" 
            placeholder="Search intel..." 
            className="w-full bg-[#16161e] border border-white/10 rounded-lg py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-primary transition-all text-on-surface"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
          <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
          <span className="text-[10px] font-bold text-primary uppercase tracking-widest">Real-time processing</span>
        </div>
        <button className="p-2 hover:bg-white/5 rounded-full transition-colors relative text-slate-400 hover:text-white cursor-pointer">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full border-2 border-[#0a0a0f]" />
        </button>
        <button className="p-2 hover:bg-white/5 rounded-full transition-colors text-slate-400 hover:text-white cursor-pointer">
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};

// --- View: Dashboard ---

const DashboardView = () => {
  return (
    <motion.div 
      key="dashboard"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="space-y-6"
    >
      <section className="glass-card rounded-2xl p-8 border-l-4 border-l-primary-container relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-6 pointer-events-none">
          <Sparkles className="w-12 h-12 text-primary opacity-20 group-hover:opacity-40 transition-opacity rotate-12" />
        </div>
        <div className="relative z-10">
          <h2 className="text-3xl font-bold text-white mb-2">AI Daily Briefing</h2>
          <p className="text-on-surface-variant text-lg mb-8 max-w-2xl">
            Good morning. Your stack is stable, but 3 critical follow-ups require attention before the investor sync at 2 PM.
          </p>
          <ul className="space-y-4">
            {[
              "Venture pipeline analysis: 12 new high-match leads identified in Series A fintech.",
              "Cloud expenditure: Potential 14% optimization identified in AWS region us-east-1.",
              "Team sentiment: Engagement up 4% following the updated equity roadmap announcement.",
              "Product roadmap: Feature 'Orbit-Sync' is 3 days ahead of the original Q3 milestone.",
              "Market Pulse: Competitor 'Nexus AI' pivoted messaging towards SME automation."
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-4 group/item">
                <CheckCircle2 className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <span className="text-on-surface group-hover/item:text-white transition-colors">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Follow-ups', title: 'Action Required', status: '3 OVERDUE', icon: AlertTriangle, color: 'text-error', bgColor: 'bg-error-container/20' },
          { label: 'Stack Monitor', title: 'Latency Detected', status: '2 ALERTS', icon: Zap, color: 'text-yellow-400', bgColor: 'bg-yellow-400/20' },
          { label: 'Decisions', title: 'Strategy Vault', status: '5 LOGGED', icon: ShieldCheck, color: 'text-tertiary', bgColor: 'bg-tertiary-container/20' }
        ].map((card, i) => (
          <GlassCard key={i} className="glass-card-hover cursor-pointer border-white/5">
            <div className="flex justify-between items-start mb-6">
              <div className={`p-2 rounded-lg ${card.bgColor}`}>
                <card.icon className={`w-5 h-5 ${card.color}`} />
              </div>
              <span className="bg-white/5 text-[10px] font-bold text-slate-400 px-3 py-1 rounded-full uppercase tracking-widest">{card.status}</span>
            </div>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mb-1">{card.label}</p>
            <h3 className="text-white text-xl font-bold">{card.title}</h3>
          </GlassCard>
        ))}
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-12 lg:col-span-7 glass-card rounded-2xl p-8">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-bold text-white">Recent Activity</h3>
            <button className="text-primary text-xs font-bold uppercase tracking-widest hover:underline cursor-pointer">View All</button>
          </div>
          <div className="space-y-8 relative">
            <div className="absolute left-[15px] top-4 bottom-4 w-px bg-white/5" />
            {[
              { icon: Mail, title: 'Follow-up sent', desc: 'to Sequoia Capital regarding Seed II deck.', time: 'Today, 09:42 AM' },
              { icon: History, title: 'Stack Auto-optimized', desc: 'Switched primary DNS to Cloudflare Edge.', time: 'Yesterday, 11:20 PM' },
              { icon: UserPlus, title: 'New Lead Found', desc: "AI Agent matched 'Sarah Chen' for CTO role.", time: 'Yesterday, 06:15 PM' }
            ].map((activity, i) => (
              <div key={i} className="flex gap-6 relative">
                <div className="w-8 h-8 rounded-full bg-surface-container border border-white/5 flex items-center justify-center shrink-0 z-10">
                  <activity.icon className="w-3 h-3 text-primary" />
                </div>
                <div>
                  <p className="text-white">
                    <span className="font-bold">{activity.title}</span> {activity.desc}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="col-span-12 lg:col-span-5 glass-card rounded-2xl overflow-hidden flex flex-col group">
          <div className="h-48 relative overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80" 
              alt="AI Insights"
              className="w-full h-full object-cover grayscale transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-surface to-transparent" />
            <div className="absolute bottom-6 left-6 flex items-center gap-2 bg-primary/20 backdrop-blur-md border border-primary/30 px-3 py-1 rounded-full">
              <Sparkles className="w-4 h-4 text-primary fill-primary" />
              <span className="text-[10px] font-bold text-primary uppercase tracking-widest">Orbit Insight</span>
            </div>
          </div>
          <div className="p-8 flex-1">
            <h4 className="text-2xl font-bold text-white mb-4">Market Shift Detected</h4>
            <p className="text-on-surface-variant mb-8 line-clamp-3">
              Your current burn rate is 12% lower than sector average. AI suggests re-allocating $15k to R&D for the new API feature set.
            </p>
            <button className="w-full py-4 bg-primary-container text-white font-bold rounded-xl ai-glow transition-transform active:scale-[0.98] hover:brightness-110 cursor-pointer">
              Execute Recommendation
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// --- View: Follow-ups ---

const FollowUpsView = () => {
  const contacts = [
    { name: 'Julian Draper', company: 'Sequoia Capital', type: 'Investor', initial: 'JD', status: '7 Days Overdue', urgent: true, desc: '"Mentioned he wanted to see the updated series A deck by Tuesday. Need to send over the new ARR projections."' },
    { name: 'Sarah Koenig', company: 'Scale AI', type: 'Customer', initial: 'SK', status: 'Due in 2 days', urgent: false, desc: '"Following up on the enterprise pilot feedback. She was interested in the API latency improvements."' },
    { name: 'Marcus Thorne', company: 'Stripe', type: 'Lead', initial: 'MT', status: 'Up to date', urgent: false, desc: '"Initial discovery call completed. Scheduled product demo for next month. No immediate action."', ok: true },
    { name: 'Elena Lu', company: 'Founders Fund', type: 'Investor', initial: 'EL', status: '2 Days Overdue', urgent: true, desc: '"Waitlisted. She asked for an intro to our head of engineering. Need to coordinate the bridge email."' },
    { name: 'Ben Wright', company: 'Vercel', type: 'Customer', initial: 'BW', status: 'Due tomorrow', urgent: false, desc: '"Contract is in legal review. Check if they need any more documentation on data privacy."' }
  ];

  return (
    <motion.div 
      key="follow-ups"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-8 pb-12"
    >
      <div className="flex justify-between items-end">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-[10px] font-bold text-primary uppercase tracking-widest">Action Required</span>
          </div>
          <h2 className="text-4xl font-bold text-white">Follow-ups</h2>
          <p className="text-on-surface-variant mt-2 font-medium">AI-prioritized relationship management</p>
        </div>
        <button className="bg-primary-container hover:bg-[#6d28d9] text-white px-6 py-4 rounded-xl font-bold flex items-center gap-3 transition-all ai-glow active:scale-95 cursor-pointer">
          <Plus className="w-5 h-5" />
          Add Contact
        </button>
      </div>

      <div className="flex items-center gap-3">
        {['All', 'Overdue', 'Pending', 'Done'].map((filter, i) => (
          <button 
            key={i}
            className={`px-6 py-2 rounded-full text-sm font-bold transition-all cursor-pointer ${
              i === 0 ? 'bg-primary text-on-primary' : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 border border-white/5'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {contacts.map((contact, i) => (
          <GlassCard key={i} className="flex flex-col group hover:border-primary/40 transition-all duration-300">
            <div className="flex justify-between items-start mb-6">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg border ${
                contact.initial === 'JD' || contact.initial === 'EL' ? 'bg-error-container/20 text-error border-error/30' : 
                contact.ok ? 'bg-tertiary-container/20 text-tertiary border-tertiary/30' : 'bg-secondary-container/20 text-secondary border-secondary/30'
              }`}>
                {contact.initial}
              </div>
              <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 ${
                contact.urgent ? 'bg-error-container text-on-error-container' : 'bg-white/5 text-slate-400'
              }`}>
                {contact.urgent ? <AlertTriangle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                {contact.status}
              </span>
            </div>

            <div>
              <h3 className="text-white font-bold text-xl">{contact.name}</h3>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[10px] bg-white/5 border border-white/10 px-2 py-0.5 rounded uppercase font-bold text-slate-400">{contact.type}</span>
                <span className="text-slate-500 text-sm">• {contact.company}</span>
              </div>
            </div>

            <div className="mt-6 mb-8 p-4 bg-white/[0.02] rounded-lg border border-white/5">
              <p className="text-sm text-slate-400 line-clamp-2 italic leading-relaxed">{contact.desc}</p>
            </div>

            <div className="mt-auto grid grid-cols-2 gap-4">
              <button className="py-3 text-slate-300 font-bold text-xs bg-white/5 rounded-lg border border-white/5 hover:bg-white/10 transition-colors cursor-pointer">View History</button>
              <button className="py-3 bg-primary-container/20 text-primary hover:bg-primary-container/30 font-bold text-xs border border-primary-container/30 rounded-lg transition-colors cursor-pointer">Draft Email</button>
            </div>
          </GlassCard>
        ))}

        <div className="glass-card rounded-xl border-dashed border-white/10 flex flex-col items-center justify-center text-center p-12 group cursor-pointer hover:border-primary/50 transition-colors">
          <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
            <UserPlus className="w-6 h-6 text-slate-500 group-hover:text-primary" />
          </div>
          <p className="text-slate-400 font-medium">Have a new lead?</p>
          <button className="mt-2 text-primary font-bold hover:underline cursor-pointer">Sync from LinkedIn</button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6 pt-6">
        <GlassCard className="col-span-12 lg:col-span-8 relative overflow-hidden flex flex-col">
          <div className="absolute top-6 right-6 flex items-center gap-2 p-1.5 px-3 rounded-full bg-primary/10 border border-primary/20">
            <div className="w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_#7c3aed]" />
            <span className="text-[10px] font-black uppercase tracking-widest text-primary">AI Intelligence Pulse</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">Follow-up Velocity</h3>
          <p className="text-slate-400 max-w-md mb-12">
            Your average response time to investors has improved by 22% this week. Maintaining this pace is critical for your Series A momentum.
          </p>
          
          <div className="flex items-end gap-3 h-32 mt-auto">
            {[40, 65, 55, 90, 45, 70, 60].map((h, i) => (
              <motion.div 
                key={i}
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                transition={{ delay: i * 0.1, duration: 1 }}
                className={`flex-1 rounded-t-lg transition-all ${i === 3 ? 'bg-primary-container ai-glow' : 'bg-white/5 hover:bg-primary/20'}`} 
              />
            ))}
          </div>
        </GlassCard>

        <div className="col-span-12 lg:col-span-4 glass-card rounded-2xl p-8 flex flex-col justify-between">
          <div>
            <Sparkles className="w-10 h-10 text-primary mb-6" />
            <h3 className="text-2xl font-bold text-white mb-2">Drafting Assistant</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Orbit AI has prepared 4 draft emails based on your last 24h of Slack and Email activity.
            </p>
          </div>
          <button className="w-full mt-12 py-4 bg-white text-[#0a0a0f] rounded-xl font-black uppercase tracking-widest hover:bg-primary transition-all active:scale-95 shadow-xl cursor-pointer">
            Review All Drafts
          </button>
        </div>
      </div>
    </motion.div>
  );
};

// --- View: Stack Monitor ---

const StackMonitorView = () => {
  return (
    <motion.div 
      key="stack-monitor"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      className="space-y-8"
    >
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-bold text-white">Stack Monitor</h2>
          <p className="text-on-surface-variant font-medium mt-2">Real-time intelligence on your technological infrastructure.</p>
        </div>
        <button className="bg-primary-container text-white px-6 py-4 rounded-xl font-bold flex items-center gap-3 ai-glow active:scale-95 transition-all cursor-pointer">
          <Plus className="w-5 h-5" />
          Add Tool
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'CRITICAL', val: '01', desc: 'Systemic failure predicted in Node API clusters.', status: 'Urgent', icon: AlertOctagon, color: 'text-error' },
          { label: 'WARNINGS', val: '02', desc: 'Performance degradation in Postgres read-replicas.', status: 'Pending', icon: AlertTriangle, color: 'text-yellow-400' },
          { label: 'NO CHANGES', val: '04', desc: 'Security patches applied. Core services optimal.', status: 'Stable', icon: ShieldCheck, color: 'text-tertiary' }
        ].map((stat, i) => (
          <GlassCard key={i} className="relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity">
              <stat.icon size={96} />
            </div>
            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em]">{stat.label}</p>
            <div className="flex items-baseline gap-4 mt-4">
              <span className="text-6xl font-black text-white">{stat.val}</span>
              <span className={`${stat.color} font-bold text-xs flex items-center gap-1 bg-white/5 py-1 px-3 rounded-full border border-white/5`}>
                <Circle className="w-2 h-2 fill-current" /> {stat.status}
              </span>
            </div>
            <p className="text-slate-400 text-sm mt-6 leading-relaxed">{stat.desc}</p>
          </GlassCard>
        ))}
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center px-2">
          <h3 className="text-xl font-bold text-white">Recent Activity Feed</h3>
          <div className="flex gap-2">
            <button className="px-4 py-1.5 rounded-lg text-xs font-bold bg-white/5 text-slate-400 border border-white/10 hover:text-white transition-colors cursor-pointer">All Events</button>
            <button className="px-4 py-1.5 rounded-lg text-xs font-bold bg-primary/20 text-primary border border-primary/20 cursor-pointer">Unresolved</button>
          </div>
        </div>

        <div className="glass-card rounded-2xl overflow-hidden border-l-4 border-l-error p-6 flex gap-6">
          <div className="w-12 h-12 rounded-xl bg-surface-container border border-white/5 flex items-center justify-center shrink-0">
            <Cloud className="text-white w-6 h-6" />
          </div>
          <div className="flex-1 space-y-4">
            <div className="flex justify-between items-center">
              <h4 className="text-xl font-bold text-white">AWS Infrastructure</h4>
              <span className="px-3 py-1 bg-error-container text-on-error-container text-[10px] font-black uppercase tracking-widest rounded-full">Critical Alert</span>
            </div>
            <p className="text-on-surface-variant leading-relaxed">
              Unauthorized access attempts detected on Port 443 originating from multiple APAC regions.
            </p>
            <div className="flex gap-6 text-xs text-slate-500 font-medium">
              <span className="flex items-center gap-2"><Clock size={12} /> Oct 24, 14:22 UTC</span>
              <span className="flex items-center gap-2"><History size={12} /> 2 hours ago</span>
            </div>
            
            <div className="mt-8 p-6 rounded-xl bg-primary/5 border border-primary/10 space-y-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <span className="bg-primary/20 text-primary px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest">AI Insight</span>
                  <span className="text-white font-bold text-sm">Recommended Action</span>
                </div>
                <ChevronUp className="w-4 h-4 text-slate-500" />
              </div>
              <p className="text-slate-300 text-sm leading-relaxed">
                Our analysis suggests a coordinated brute-force attack. Immediate action: Enable IP rate-limiting on CloudFront and rotate IAM keys for the production service role.
              </p>
              <div className="flex gap-4">
                <button className="bg-primary-container hover:bg-[#6d28d9] text-white px-6 py-2 rounded-lg text-xs font-bold transition-all ai-glow cursor-pointer">Apply Patch</button>
                <button className="bg-white/5 border border-white/10 hover:bg-white/10 text-white px-6 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer">Quarantine</button>
              </div>
            </div>
          </div>
        </div>

        <div className="glass-card rounded-2xl overflow-hidden border-l-4 border-l-yellow-400 p-6 flex gap-6 opacity-80 hover:opacity-100 transition-opacity">
          <div className="w-12 h-12 rounded-xl bg-surface-container border border-white/5 flex items-center justify-center shrink-0">
            <Database className="text-white w-6 h-6" />
          </div>
          <div className="flex-1 space-y-4">
            <div className="flex justify-between items-center">
              <h4 className="text-xl font-bold text-white">PostgreSQL Primary</h4>
              <span className="px-3 py-1 bg-yellow-400/20 text-yellow-400 text-[10px] font-black uppercase tracking-widest rounded-full">Performance Warning</span>
            </div>
            <p className="text-on-surface-variant leading-relaxed">
              Transaction throughput dropped by 14% in the last 30 minutes. High I/O wait detected.
            </p>
            <div className="flex items-center justify-between">
              <div className="flex gap-6 text-xs text-slate-500 font-medium">
                <span className="flex items-center gap-2"><Clock size={12} /> Oct 24, 11:45 UTC</span>
                <span className="flex items-center gap-2"><History size={12} /> 5 hours ago</span>
              </div>
              <ChevronDown className="w-4 h-4 text-slate-500 cursor-pointer" />
            </div>
          </div>
        </div>
      </div>

      <div className="glass-card rounded-2xl h-[400px] relative overflow-hidden p-8 flex flex-col justify-between">
         <img 
          src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1200&q=80" 
          alt="Topology"
          className="absolute inset-0 w-full h-full object-cover opacity-[0.07]"
        />
        <div className="relative z-10 flex justify-between items-start">
          <div>
            <p className="text-primary text-[10px] font-bold uppercase tracking-[0.3em] mb-2">Live Stack Topology</p>
            <h3 className="text-3xl font-bold text-white">Global Distribution Network</h3>
          </div>
          <div className="flex gap-3">
            <div className="bg-[#051424]/80 backdrop-blur-md border border-white/10 px-4 py-2 rounded-xl flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-tertiary shadow-[0_0_8px_#89ceff]" />
              <span className="text-xs font-bold text-white">12 Nodes Online</span>
            </div>
            <div className="bg-[#051424]/80 backdrop-blur-md border border-white/10 px-4 py-2 rounded-xl flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-error animate-ping" />
              <span className="text-xs font-bold text-white">1 Critical Node</span>
            </div>
          </div>
        </div>

        <div className="relative z-10 mx-auto flex items-center gap-8 p-6 px-12 glass-card rounded-full shadow-2xl">
          {[
            { label: 'Uptime', val: '99.9%' },
            { label: 'Latency', val: '42ms' },
            { label: 'Req/Sec', val: '2.1k' }
          ].map((item, i) => (
            <React.Fragment key={i}>
              <div className="text-center">
                <p className="text-2xl font-black text-white">{item.val}</p>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{item.label}</p>
              </div>
              {i < 2 && <div className="h-8 w-px bg-white/10" />}
            </React.Fragment>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

// --- View: Chat ---

const ChatView = () => {
  const [messages] = useState([
    { role: 'ai', time: '10:42 AM', content: "Welcome back. I've analyzed your current fundraising metrics. Based on your current engineering velocity, you have enough runway to delay the Series B by 4 months, which could increase your valuation by approximately 15% if current growth holds. What would you like to focus on?" },
    { role: 'user', time: '10:43 AM', content: "That's interesting. What if we accelerated engineering hiring now? How does that impact the valuation versus the burn rate increase?" },
    { role: 'ai', time: '10:44 AM', content: "Accelerating hiring by 30% (adding 4 senior devs) would shorten your runway by 6 weeks. However, engineering velocity would likely increase by 22% after an initial 3-week onboarding dip. This would allow the 'Enterprise Gateway' feature to launch in Q2 instead of Q3, potentially unlocking $2M in ARR ahead of the fundraiser.", insight: "Revenue Growth +12% YoY | Burn Rate Increase $120k/mo" },
    { role: 'user', time: '10:45 AM', content: "Okay, let's look at the engineering velocity data from last sprint. Why was there a bottleneck in the PR review stage?" }
  ]);

  return (
    <motion.div 
      key="chat"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex h-[calc(100vh-64px)] -m-8 overflow-hidden bg-surface"
    >
      {/* Context Panel */}
      <aside className="w-[30%] border-r border-white/5 p-8 overflow-y-auto space-y-8 glass-card border-none rounded-none shadow-none no-scrollbar">
        <h2 className="text-2xl font-bold text-white mb-8">Current Context</h2>
        
        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <span className="text-[10px] font-bold text-primary uppercase tracking-widest">Active Follow-ups</span>
            <Bell className="w-3 h-3 text-primary" />
          </div>
          <div className="glass-card p-6 rounded-2xl border-white/5 space-y-4">
            <div className="flex items-start gap-4">
              <CheckCircle2 className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <p className="text-sm text-white">Confirm engineering headcount with CTO by EOD.</p>
            </div>
            <div className="flex items-start gap-4">
              <Circle className="w-5 h-5 text-slate-500 mt-0.5 shrink-0" />
              <p className="text-sm text-slate-400">Review final term sheet from Sequoia.</p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <span className="text-[10px] font-bold text-error uppercase tracking-widest">Stack Alerts</span>
            <AlertOctagon className="w-3 h-3 text-error" />
          </div>
          <div className="glass-card p-6 rounded-2xl border-error/20 bg-error-container/5">
            <p className="text-sm font-bold text-error mb-2">Compute Spike Detected</p>
            <p className="text-xs text-slate-400 leading-relaxed">AWS Lambda costs trending 40% above forecast in us-east-1.</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <span className="text-[10px] font-bold text-tertiary uppercase tracking-widest">Last Decision</span>
            <TrendingUp className="w-3 h-3 text-tertiary" />
          </div>
          <div className="glass-card p-6 rounded-2xl border-white/5">
            <p className="text-sm text-white italic leading-relaxed">"Approved the pivot to enterprise-grade SOC2 compliance by Q3."</p>
            <div className="mt-4 flex items-center gap-4">
              <span className="text-[10px] font-bold text-slate-500 tracking-tighter">2 HOURS AGO</span>
              <div className="h-px flex-1 bg-white/5" />
            </div>
          </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <section className="flex-1 flex flex-col relative chat-gradient shadow-2xl">
        <header className="h-16 px-8 flex items-center justify-between border-b border-white/5 bg-[#0a0a0f]/40 backdrop-blur-md">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-primary-container/20 border border-primary/20 flex items-center justify-center ai-glow">
              <Orbit className="text-primary w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Orbit Intelligence</h3>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Active Insight Agent</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 glass-card border-white/10 rounded-lg text-xs font-bold text-white hover:bg-white/10 transition-all cursor-pointer">Clear Thread</button>
            <button className="px-4 py-2 bg-primary-container rounded-lg text-xs font-bold text-white shadow-lg shadow-primary/20 hover:brightness-110 active:scale-95 transition-all cursor-pointer">Export Summary</button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 space-y-12 no-scrollbar">
          {messages.map((msg, i) => (
            <div key={i} className={`flex gap-6 max-w-2xl ${msg.role === 'user' ? 'ml-auto justify-end' : ''}`}>
              {msg.role === 'ai' && (
                <div className="w-8 h-8 rounded-full bg-primary-container border border-primary/30 flex items-center justify-center shrink-0 ai-glow">
                  <Orbit className="w-4 h-4 text-white" />
                </div>
              )}
              <div className={`p-6 rounded-2xl shadow-xl transition-all ${
                msg.role === 'ai' 
                  ? 'bg-surface-container-high border border-white/5 rounded-tl-none text-on-surface' 
                  : 'bg-primary-container text-white rounded-tr-none'
              }`}>
                <p className="text-sm leading-relaxed text-balance">{msg.content}</p>
                {msg.insight && (
                  <div className="mt-4 p-4 rounded-xl bg-white/5 border border-white/5">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-3 h-3 text-tertiary" />
                      <span className="text-[10px] font-black text-tertiary uppercase tracking-widest">Model Projection</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">{msg.insight}</p>
                  </div>
                )}
                <span className={`text-[10px] mt-4 block font-bold tracking-widest ${msg.role === 'ai' ? 'text-slate-500' : 'text-white/50 text-right'}`}>
                  {msg.time}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="p-8 border-t border-white/5 bg-[#0a0a0f] backdrop-blur-md">
          <div className="max-w-4xl mx-auto glass-card flex items-center gap-4 p-2 pl-4 pr-3 rounded-2xl border-white/10 focus-within:ring-1 focus-within:ring-primary/40 transition-all">
            <button className="p-2 hover:bg-white/5 rounded-xl text-slate-500 hover:text-white transition-all cursor-pointer">
              <Paperclip size={20} />
            </button>
            <input 
              type="text" 
              placeholder="Ask anything about your stack, fundraising, or roadmap..."
              className="flex-1 bg-transparent border-none focus:ring-0 text-white placeholder-slate-600 text-sm py-3"
            />
            <button className="w-12 h-12 bg-primary-container rounded-xl flex items-center justify-center shadow-lg shadow-primary/30 hover:brightness-110 active:scale-95 transition-all cursor-pointer">
              <Send size={18} className="text-white" />
            </button>
          </div>
          <p className="text-center text-[9px] text-slate-600 mt-6 font-bold uppercase tracking-[0.3em]">Orbit AI can hallucinate. Verify critical financial data.</p>
        </div>
      </section>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [currentTab, setCurrentTab] = useState('dashboard');

  const renderContent = () => {
    switch (currentTab) {
      case 'dashboard': return <DashboardView />;
      case 'follow-ups': return <FollowUpsView />;
      case 'stack-monitor': return <StackMonitorView />;
      case 'chat': return <ChatView />;
      default: return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-surface selection:bg-[#7c3aed]/30 scroll-smooth no-scrollbar">
      <Sidebar currentTab={currentTab} onTabChange={setCurrentTab} />
      <div className="ml-64 min-h-screen flex flex-col">
        <TopBar />
        <main className={`p-8 mt-16 flex-1 ${currentTab === 'chat' ? 'overflow-hidden' : ''}`}>
          <div className={`${currentTab === 'chat' ? 'h-full' : 'max-w-7xl mx-auto'}`}>
            <AnimatePresence mode="wait">
              {renderContent()}
            </AnimatePresence>
          </div>
        </main>
      </div>
      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
}
