---
name: Stellar Precision
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#ccc3d8'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#958da1'
  outline-variant: '#4a4455'
  surface-tint: '#d2bbff'
  primary: '#d2bbff'
  on-primary: '#3f008e'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#732ee4'
  secondary: '#cebdff'
  on-secondary: '#381385'
  secondary-container: '#4f319c'
  on-secondary-container: '#bea8ff'
  tertiary: '#89ceff'
  on-tertiary: '#00344d'
  tertiary-container: '#006d9c'
  on-tertiary-container: '#cfe9ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#e8ddff'
  secondary-fixed-dim: '#cebdff'
  on-secondary-fixed: '#21005e'
  on-secondary-fixed-variant: '#4f319c'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  h1:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: '0'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 24px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  grid_columns: '12'
  gutter: 24px
---

## Brand & Style

The visual identity of this design system is built upon the concept of "The Digital Void"—a high-performance, deep-space aesthetic tailored for founders who require clarity amidst complex AI data. It balances a **Minimalist** structure with **Glassmorphism** depth to create a premium, high-fidelity experience.

The system evokes a sense of calm authority and technological sophistication. By utilizing a deep black foundation, we minimize cognitive load and allow the vibrant AI-driven insights to resonate. The style is strictly professional, avoiding unnecessary ornamentation in favor of functional elegance and a strong visual hierarchy that guides the user through critical decision-making paths.

## Colors

The color palette is anchored by a true-black background (#0a0a0f) to maximize contrast and screen efficiency. The primary purple (#7c3aed) serves as the "energy source" for the UI, used for primary actions and critical AI states, while the secondary violet (#a78bfa) provides a softer tonal range for accents and supportive data visualizations.

Neutral tones are slightly cool-shifted to maintain a cohesive atmospheric feel. Functional colors (success, warning, error) should be used sparingly but with high saturation to ensure they cut through the dark interface immediately.

## Typography

This design system utilizes **Inter** exclusively to leverage its exceptional legibility in data-dense environments. The typographic scale is designed with a dramatic contrast between large, bold headlines and utilitarian body text.

To maintain a premium feel, headlines use tighter letter spacing, while smaller labels utilize increased tracking for clarity against the dark background. Use `font-feature-settings: 'tnum' ON` for all numerical data within the dashboard to ensure tabular alignment in AI-generated reports and metrics.

## Layout & Spacing

The layout is governed by a **fixed-fluid hybrid grid** based on a 24px rhythm. The primary dashboard structure uses a 12-column grid with 24px gutters to ensure consistent alignment of high-level information cards.

Padding and margins should strictly follow the 24px increment or its sub-multiples (8px, 16px) to maintain a rigid, professional structure. Negative space is used as a primary tool for grouping related AI insights, ensuring the dashboard remains uncluttered even when displaying complex data sets.

## Elevation & Depth

Depth in this design system is achieved through **Glassmorphism** and tonal layering rather than traditional heavy shadows. 

1.  **Background (Level 0):** Deep black (#0a0a0f).
2.  **Base Cards (Level 1):** Semi-transparent surfaces (80% opacity) with a 12px backdrop blur. Borders are 1px solid, using a low-opacity white (10%) to create a "etched glass" effect.
3.  **Floating Elements (Level 2):** Increased transparency (60% opacity) with a 20px backdrop blur and a soft, purple-tinted ambient shadow (0px 20px 40px rgba(124, 58, 237, 0.15)) to indicate interactivity or focus.

Avoid opaque backgrounds for cards; the "glass" effect is essential to the brand’s high-fidelity identity.

## Shapes

The shape language is sophisticated and modern, utilizing a **Rounded** (Level 2) corner strategy. Standard components like buttons and small cards use an 8px (0.5rem) radius, while larger dashboard containers and primary glass cards use a 16px (1rem) radius to soften the interface.

Interactive states should never result in sharp corners. The consistency of these radii reinforces the premium, hardware-inspired aesthetic of the dashboard.

## Components

### Buttons
Primary buttons are solid #7c3aed with white text, featuring a subtle outer glow on hover. Secondary buttons use a "ghost glass" style: a transparent background with the 1px etched border and violet text.

### Cards
The signature component. Must include `backdrop-filter: blur(12px)`, a 1px border (#ffffff at 10% opacity), and a padding of 24px. Headers within cards should be separated by a subtle 1px divider.

### Input Fields
Inputs should have a dark, recessed appearance (#16161e) with a 1px border that transitions to purple (#7c3aed) upon focus. Typography inside inputs remains `body-md`.

### Chips & Badges
Small, pill-shaped indicators for AI status or categories. Use a low-opacity purple fill (15%) with high-saturation violet text for a "neon-on-glass" effect.

### AI Activity Monitor
A custom component featuring a pulsing violet dot and a condensed font-weight label to indicate real-time data processing, placed in the top-right of primary cards.